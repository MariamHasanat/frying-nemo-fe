const MyMajer = () =>{
    const major = "computer since engineering";
    const year = " 2020";
    const full = major+year;
    return(
        <p>
            My studing major and year is : {full};
        </p>
    )

}
export default MyMajer;