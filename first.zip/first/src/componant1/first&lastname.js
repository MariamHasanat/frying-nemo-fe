const MyName = () =>{
    const first  = "sajeda";
    const last = " swad";
    const full = last+first;
    return(
        <p>
            My name is : {full};
        </p>
    )

}
export default MyName;